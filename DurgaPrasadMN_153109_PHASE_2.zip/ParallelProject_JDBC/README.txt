create table customer(mobilenumber varchar2(10) primary key,name varchar2(20),balance number(20,2));


create table wallet(mobilenumber varchar2(10),transactiontype varchar2(20),transactiondate date,balance number(20,2));

